﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WakulimaSaccoSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void manageMembersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void newMemberToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmmembernew frm = new frmmembernew();
            frm.ShowDialog();
        }

        private void manageMembersToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmmembers frm = new frmmembers();
            frm.ShowDialog();
        }

        private void memberContributionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmcontributions frm = new frmcontributions();
            frm.ShowDialog();
        }

        private void loansToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmloans frm = new frmloans();
            frm.ShowDialog();
        }

        private void aboutUsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmaboutus frm = new frmaboutus();
            frm.ShowDialog();
        }

        private void systemSettingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmsystemsettings frm = new frmsystemsettings();
            frm.ShowDialog();
        }
    }
}
