﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;

namespace WakulimaSaccoSystem
{
    static class Program
    {
        public static string GetMemberIdNumber(string ID)
        {
            string sql = "SELECT [ID_Num] FROM [members] WHERE [ID] = @id";
            OleDbCommand cmd = new OleDbCommand();
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("id", ID);
            DataTable dt = db.ReadFromDB(cmd);

            if (dt.Rows.Count == 1)
            {
                return dt.Rows[0][0].ToString();
            }
            else
            {
                return "";
            }

        }

        public static string GetMemberName(string ID)
        {
            string sql = "SELECT [MemberName] FROM [members] WHERE [ID] = @idnum";
            OleDbCommand cmd = new OleDbCommand();
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("idnum", ID);
            DataTable dt = db.ReadFromDB(cmd);

            if (dt.Rows.Count == 1)
            {
                return dt.Rows[0][0].ToString();
            }
            else
            {
                return "";
            }

        }
        public static string GetMemberSystemID(string IDNumber)
        {
            string sql = "SELECT [ID] FROM [members] WHERE [ID_Num] = @idnum";
            OleDbCommand cmd = new OleDbCommand();
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("idnum", IDNumber);
            DataTable dt = db.ReadFromDB(cmd);

            if(dt.Rows.Count == 1)
            {
                return dt.Rows[0][0].ToString();
            }
            else
            {
                return "";
            }

        }
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
           
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            if(!System.IO.Directory.Exists(Application.StartupPath + "/passport"))
            {
                //create the passport folder
                System.IO.Directory.CreateDirectory(Application.StartupPath + "/passport");
            }

            frmsplash frm = new frmsplash();
            DialogResult d = frm.ShowDialog();
            if(d == DialogResult.OK)
            {
                Application.Run(new Form1());
            }
           
        }
    }
}
