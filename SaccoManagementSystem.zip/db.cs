﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;


namespace WakulimaSaccoSystem
{
    class db
    {

        private static String OleDBProvider = "Microsoft.ACE.OLEDB.12.0"; // "Microsoft.JET.OLEDB.4.0"; //if ACE Microsoft.ACE.OLEDB.12.0
        private static String OleDBDataSource = Application.StartupPath + @"\data.accdb";
        private static String OleDBPassword = "";
        private static String PersistSecurityInfo = "true";

        public static string ConnectionString()
        {
           string constring = @"Provider = " + OleDBProvider + "; Data Source = " + OleDBDataSource + "; JET OLEDB:Database Password = " + OleDBPassword + "; Persist Security Info = " + PersistSecurityInfo + ";";
           return constring;
        }
        public static void CreateRecord(OleDbCommand cmd)
        {
            OleDbConnection con = new OleDbConnection();
            con.ConnectionString = ConnectionString();
            con.Open();
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public static DataTable ReadFromDB(OleDbCommand cmd)
        {
            OleDbConnection con = new OleDbConnection();
            con.ConnectionString = ConnectionString();
            con.Open();
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            OleDbDataAdapter DA = new OleDbDataAdapter(cmd);
            con.Close();
            DataTable DT = new DataTable();
            DA.Fill(DT);
            return DT;
        }
    }
}
