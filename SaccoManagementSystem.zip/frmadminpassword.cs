﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WakulimaSaccoSystem
{
    public partial class frmadminpassword : Form
    {
        public frmadminpassword()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(txtusername.Text != Properties.Settings.Default.AdminUsername || txtpassword.Text != Properties.Settings.Default.AdminPassword)
            {
                MessageBox.Show("Administrator username and password are incorrect, please try again", "Wakulima Sacco", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtpassword.Text = "";
                txtusername.Text = "";
                txtusername.Focus();
            } else
            {
                this.DialogResult = DialogResult.OK;
            }
        }

        private void frmadminpassword_FormClosed(object sender, FormClosedEventArgs e)
        {
            //this.DialogResult = DialogResult.Cancel;
        }
    }
}
