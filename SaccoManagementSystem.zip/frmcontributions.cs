﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WakulimaSaccoSystem
{
    public partial class frmcontributions : Form
    {
        public frmcontributions(string IDNumber = "")
        {
            InitializeComponent();
            if(IDNumber != "")
            {
                txtidnumber.Text = IDNumber;
                btnlookup.PerformClick();
            } else
            {
                LoadAll();
            }
        }

        private void LoadAll()
        {
            string sql = "SELECT * FROM [MemberContribution]";
            OleDbCommand cmd = new OleDbCommand();
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            DataTable dt = db.ReadFromDB(cmd);
            loadtoGrid(dt);

        }

        private void LoadSpecificMember(string IDNumber)
        {
            string MemberSystemID = Program.GetMemberSystemID(IDNumber);
            if(MemberSystemID == "")
            {
                MessageBox.Show("An error occurred while trying to fetch member details, possible causes are: " + Environment.NewLine + " Incorrect Member ID Number or " + Environment.NewLine + "Two members share the same ID Number", "Wakulima Sacco", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtidnumber.Focus();
                return;
            }
            string sql = "SELECT * FROM [MemberContribution]";
            OleDbCommand cmd = new OleDbCommand();
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            DataTable dt = db.ReadFromDB(cmd);
            loadtoGrid(dt);

        }

        private void loadtoGrid(DataTable dt)
        {
            grid.Rows.Clear();

            if (dt.Rows.Count > 0)
            {
                int rowID = 0;
                foreach (DataRow dr in dt.Rows)
                {
                    grid.Rows.Add(
                            dr["ID"].ToString(),
                            Program.GetMemberName(dr["MemberID"].ToString()),
                            dr["Amount"].ToString(),
                            dr["Mode"].ToString(),
                            dr["TransID"].ToString(),
                            dr["DatePaid"].ToString(),
                            dr["Note"].ToString()
                        );
                    grid.Rows[rowID].HeaderCell.Value = (rowID + 1).ToString();
                    rowID++;
                }
            }
        }
        private void frmcontributions_Load(object sender, EventArgs e)
        {

        }

        private void btnlookup_Click(object sender, EventArgs e)
        {
            LoadSpecificMember(txtidnumber.Text);
        }

        private void addContributionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmcontributionsadd frm = new frmcontributionsadd();
            DialogResult d = frm.ShowDialog();
            if(d == DialogResult.OK)
            {
                LoadAll();
            }
        }
    }
}
