﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WakulimaSaccoSystem
{
    public partial class frmcontributionsadd : Form
    {
        public frmcontributionsadd()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(Program.GetMemberSystemID(txtidnumber.Text) == "")
            {
                MessageBox.Show("The identification number provided is not associated to any member.", "Wakulima Sacco", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtidnumber.Focus();
                return;
            }


            if(txtamount.Value < 1)
            {
                MessageBox.Show("Please enter the amount paid for this contribution", "Wakulima Sacco", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtamount.Focus();
                return;
            }

            string sql = "INSERT INTO [MemberContribution] ([MemberID], [CyclePaid], [Amount], [Mode], [TransID], [DatePaid], [Note])";
            sql += "VALUES (@mid, @cycle, @amount, @mode, @transid, @date, @note)";

            OleDbCommand cmd = new OleDbCommand();
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("mid", Program.GetMemberSystemID(txtidnumber.Text));
            cmd.Parameters.AddWithValue("cycle", txtfor.Text);
            cmd.Parameters.AddWithValue("amount", txtamount.Value);
            cmd.Parameters.AddWithValue("mode", cbopaymentmode.Text);
            cmd.Parameters.AddWithValue("transid", txttransid.Text);
            cmd.Parameters.AddWithValue("date", txtdate.Value);
            cmd.Parameters.AddWithValue("note", txtnote.Text);
            db.CreateRecord(cmd);
            MessageBox.Show("Member contribution has been added successfully", "Wakulima Sacco", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
            txtfor.Text = "";
            cbopaymentmode.Text = "";
            txttransid.Text = "";
            txtnote.Text = "";
            txtamount.Value = 0;


        }

        private void frmcontributionsadd_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        private void txtname_Leave(object sender, EventArgs e)
        {
            
        }

        private void txtidnumber_Leave(object sender, EventArgs e)
        {
            txtname.Text = Program.GetMemberName(Program.GetMemberSystemID(txtidnumber.Text));
        }

        private void txtidnumber_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
