﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WakulimaSaccoSystem
{
    public partial class frmloadnew : Form
    {
        public frmloadnew()
        {
            InitializeComponent();
        }

        private void txtidnumber_Leave(object sender, EventArgs e)
        {
            txtname.Text = Program.GetMemberName(Program.GetMemberSystemID(txtidnumber.Text));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(Program.GetMemberSystemID(txtidnumber.Text) == "" )
            {
                MessageBox.Show("Please provide a valid National Identification Number", "Wakulima Sacco", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtidnumber.Focus();
                return;
            }

            if(txtamount.Value < 1)
            {
                MessageBox.Show("The loan amount can not be zero or less than zero", "Wakulima Sacco", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtamount.Focus();
                return;
            }

            //process and save loan details
            string sql = "INSERT INTO [loans] ([MemberID], [LoanAmount], [Period], [Installations], [Status], [ApplicationDate], [AprovalDate], [DisburseDate], [TotalInterest], [PaymentAmount])";
            sql += " VALUES (@mid, @loan, @period, @cycle, @status, @application, @approval, @disburse, @interest, @amount)";

            string status = Properties.Settings.Default.AppliedLoanStatus;
            string ApprovalDate = "", DisburseDate = "";

            if (chkapprove.Checked)
            {
                status = Properties.Settings.Default.ApprovedLoanStatus;
                ApprovalDate = txtdate.Value.ToString();
            }

            if(chkdisburse.Checked)
            {
                status = Properties.Settings.Default.DisbursedLoanStatus;
                ApprovalDate = txtdate.Value.ToString();
                DisburseDate = txtdate.Value.ToString();
            }

            //calculate interest & repayable amount
            int years = (int) (Convert.ToDecimal(txtperiod.Text) / 12);
            int InstallationsPerYear = (int)txtinstallations.Value / years;
            double TotalAmount = loans.CompoundInterest((double)txtamount.Value, Properties.Settings.Default.Interest, InstallationsPerYear , years);
            double interest = TotalAmount - (double)txtamount.Value;

            OleDbCommand cmd = new OleDbCommand();
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("mid", Program.GetMemberSystemID(txtidnumber.Text));
            cmd.Parameters.AddWithValue("loan", txtamount.Value);
            cmd.Parameters.AddWithValue("period", txtperiod.Text);
            cmd.Parameters.AddWithValue("cycle", txtinstallations.Value);
            cmd.Parameters.AddWithValue("status", status);
            cmd.Parameters.AddWithValue("application", txtdate.Value);
            cmd.Parameters.AddWithValue("approval", ApprovalDate);
            cmd.Parameters.AddWithValue("disburse", DisburseDate);
            cmd.Parameters.AddWithValue("interest", interest);
            cmd.Parameters.AddWithValue("amount", TotalAmount);
            db.CreateRecord(cmd);
            this.DialogResult = DialogResult.OK;
        }
    }
}
