﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WakulimaSaccoSystem
{
    public partial class frmloanrepayment : Form
    {
        public frmloanrepayment()
        {
            InitializeComponent();
        }

        private void txtidnumber_Leave(object sender, EventArgs e)
        {
            txtname.Text = Program.GetMemberName(Program.GetMemberSystemID(txtidnumber.Text));
            DataTable dt = loans.ListofMembersLoans(txtidnumber.Text);

            cboloans.Items.Clear();

            if(dt.Rows.Count > 0)
            {

                foreach(DataRow row in dt.Rows)
                {
                    string LoanDetails = (row[0].ToString() + " - " + row[1].ToString() + " (Repayment Period " + row[2].ToString() + " Months)").ToString();
                    cboloans.Items.Add(LoanDetails);
                }

                cmdpay.Enabled = true;
            }
            else
            {
                MessageBox.Show("This member does not have a loan due", "Wakulima Sacco", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtidnumber.Focus();
                cmdpay.Enabled = false;
            }

            if(cboloans.Items.Count > 0)
            {
                cboloans.SelectedIndex = 0;
            }
            
        }

        private void frmloanrepayment_Load(object sender, EventArgs e)
        {

        }

        private void txtidnumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void chkclear_CheckedChanged(object sender, EventArgs e)
        {
            if(chkclear.CheckState == CheckState.Checked)
            {
               
            }
        }
    }
}
