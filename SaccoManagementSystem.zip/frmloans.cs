﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WakulimaSaccoSystem
{
    public partial class frmloans : Form
    {
       
        

        public frmloans()
        {
            InitializeComponent();
            AllLoans.Checked = true;
            LoadLoans("");
        }

        private void newLoanApplicationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmloadnew frm = new frmloadnew();

            DialogResult d = frm.ShowDialog();
            if(d == DialogResult.OK)
            {
                //refresh grid
                ReloadGridContent();
            }
        }

        private void ReloadGridContent()
        {

        }

        private void LoadLoans(string status = "1")
        {
            if(status == "1")
            {
                status = Properties.Settings.Default.AppliedLoanStatus;
            }

            string sql = "SELECT * FROM [loans] WHERE [Status] like @status";
            OleDbCommand cmd = new OleDbCommand();
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("status", "%" + status + "%");
            cmd.CommandType = CommandType.Text;
            DataTable dt = db.ReadFromDB(cmd);
            LoadLoanstoGrid(dt);
            
        }

        private void LoadLoanstoGrid(DataTable dt)
        {
            grid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            grid.Rows.Clear();

            if (dt.Rows.Count > 0)
            {
                
                foreach(DataRow r1 in dt.Rows)
                {

                    string id = r1["id"].ToString();
                    string IDNumber = Program.GetMemberIdNumber(r1["MemberID"].ToString());
                    string MemberName = Program.GetMemberName(r1["MemberID"].ToString());
                    string status = r1["Status"].ToString();
                    string AmountBorrowed = r1["LoanAmount"].ToString();
                    string RepaymentInstallations = r1["Installations"].ToString();
                    string InterestAccrued = r1["TotalInterest"].ToString();
                    string RepaymentAmount = r1["PaymentAmount"].ToString();
                    string DateApplied = r1["ApplicationDate"].ToString();
                    string DateApproved = r1["AprovalDate"].ToString();
                    string DateDisbursed = r1["DisburseDate"].ToString();
                    string Remarks = r1["Note"].ToString();
                    string period = r1["Period"].ToString();


                    grid.Rows.Add(
                            id,
                            IDNumber,
                            MemberName,
                            status,
                            AmountBorrowed,
                            period,
                            RepaymentInstallations,
                            InterestAccrued,
                            RepaymentAmount,
                            DateApplied,
                            DateApproved,
                            DateDisbursed,
                            Remarks
                        );
                }

            }
        }

        private void loanRepaymentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmloanrepayment frm = new frmloanrepayment();
            DialogResult d = frm.ShowDialog();
            if(d == DialogResult.OK)
            {
                //refer
                ReloadGridContent();
            }
        }

        private void frmloans_Load(object sender, EventArgs e)
        {

        }

        private void pendingApproval_CheckedChanged(object sender, EventArgs e)
        {
            LoadLoans(Properties.Settings.Default.AppliedLoanStatus);
        }

        private void approvedRadio_CheckedChanged(object sender, EventArgs e)
        {
            LoadLoans(Properties.Settings.Default.ApprovedLoanStatus);
        }

        private void DisbursedRadio_CheckedChanged(object sender, EventArgs e)
        {
            LoadLoans(Properties.Settings.Default.DisbursedLoanStatus);
        }

        private void PaidRadio_CheckedChanged(object sender, EventArgs e)
        {
            LoadLoans(Properties.Settings.Default.PaidLoanStatus);
        }

        private void AllLoans_CheckedChanged(object sender, EventArgs e)
        {
            LoadLoans("");
        }

        private void grid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void approveSelectedLoanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(grid.SelectedRows.Count > 0)
            {
                foreach(DataGridViewRow row in grid.SelectedRows)
                {
                    string LoanApplicationID = row.Cells["id"].Value.ToString();
                    loans.ChangeLoanStatus(Properties.Settings.Default.ApprovedLoanStatus, LoanApplicationID);
                }

                ReloadGridContent();
                MessageBox.Show("The loan status of the selected loans was updated successfully", "Wakulima Sacco", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }

        private void disburseSelectedLoanToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (grid.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in grid.SelectedRows)
                {
                    string LoanApplicationID = row.Cells["id"].Value.ToString();
                    loans.ChangeLoanStatus(Properties.Settings.Default.DisbursedLoanStatus, LoanApplicationID);
                }

                ReloadGridContent();
                MessageBox.Show("The loan status of the selected loans was updated successfully", "Wakulima Sacco", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }

        private void printResultsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            reports_dataset itemsLbl = new reports_dataset(); //dataset whose the crystal report gets data from
            DataTable dataTable = itemsLbl.Loans;  //data table containing real data
            rptloans Report = new rptloans();

            int x = 0;
            foreach (DataGridViewRow row in grid.Rows)
            {
                x++;

                DataRow drow = dataTable.NewRow();
              
                drow["ID"] = row.Cells["id"].Value;
                drow["MemberName"] = row.Cells["MemberName"].Value;
                drow["ID Number"] = row.Cells["IDNumber"].Value;
                drow["Loan Amount"] = row.Cells["AmountBorrowed"].Value;
                drow["Period"] = row.Cells["period"].Value;
                drow["Installations"] = row.Cells["RepaymentInstallations"].Value;
                drow["status"] = row.Cells["Status"].Value;
                drow["Applied"] = row.Cells["DateApplied"].Value;
                drow["Approved"] = row.Cells["DateApproved"].Value;
                drow["Disbursed"] = row.Cells["DateDisbursed"].Value;
                drow["Interest"] = row.Cells["InterestAccrued"].Value;
                drow["TotalAmount"] = row.Cells["RepaymentAmount"].Value;

                dataTable.Rows.Add(drow);
            }

            Report.Database.Tables["Loans"].SetDataSource((DataTable)dataTable);
            frmshowreports frm = new frmshowreports(Report, "Loans Report");
            frm.ShowDialog();
        }
    }
}
