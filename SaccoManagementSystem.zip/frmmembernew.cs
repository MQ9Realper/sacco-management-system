﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;

namespace WakulimaSaccoSystem
{
    public partial class frmmembernew : Form
    {
       
        public frmmembernew()
        {
            InitializeComponent();
        }

        private void frmmembernew_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(txtmembername.Text == "")
            {
                MessageBox.Show("The member name is required", "Wakulima Sacco", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtmembername.Focus();
                return;
            }

            if (txtidnumber.Text == "")
            {
                MessageBox.Show("The member identification number is required", "Wakulima Sacco", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtidnumber.Focus();
                return;
            }

            //save file
            var SavedFileName = string.Format(@"{0}.png", Guid.NewGuid());
            var path = Application.StartupPath + "/passport/" + SavedFileName.ToString();

            if (passportsize.Image == null)
            {
                SavedFileName = "";

            }
            else
            {
                passportsize.Image.Save(path, System.Drawing.Imaging.ImageFormat.Png);
            }
            

            string sql = "INSERT INTO [members] ([MemberName], [ID_num], [PhoneNumber], [TotalShares], [PostAddress], [Passport], [DateReg])";
            sql += " VALUES (@name, @id, @phone, @shares,@postal, @passport, @date)";

            OleDbCommand cmd = new OleDbCommand();
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("name", txtmembername.Text);
            cmd.Parameters.AddWithValue("id", txtidnumber.Text);
            cmd.Parameters.AddWithValue("phone", txtphonenumber.Text);
            cmd.Parameters.AddWithValue("shares", txtshares.Text);
            cmd.Parameters.AddWithValue("postal", txtpostaladdress.Text);
            cmd.Parameters.AddWithValue("passport", SavedFileName);
            cmd.Parameters.AddWithValue("date", DateTime.Now.ToShortDateString());

            db.CreateRecord(cmd);
            this.DialogResult = DialogResult.OK;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Picture Files |*.bmp;*.jpg;*.gif;*.png;*.jpeg";
            ofd.Title = "Wakulima Sacco | Select Passport Size Photo";
            ofd.Multiselect = false;
            ofd.CheckFileExists = true;
            ofd.CheckPathExists = true;

            DialogResult d=  ofd.ShowDialog();

            if( d == DialogResult.OK)
            {
                FileStream fs = new FileStream(ofd.FileName, FileMode.Open);
                passportsize.Image = new Bitmap(fs);
            }
        }
    }
}
