﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WakulimaSaccoSystem
{
    public partial class frmmembers : Form
    {
        public frmmembers()
        {
            InitializeComponent();
            LoadMembers();

        }

        private void loadMembers2Grid(DataTable dt)
        {
            grid.Rows.Clear();

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    Bitmap bt;

                    if (dr["Passport"].ToString() != "")
                    {
                        //bt = new Bitmap(Application.StartupPath + "/passports/" + dr["Passport"].ToString());
                        using (System.IO.FileStream fs = new System.IO.FileStream(Application.StartupPath + "/passport/" + dr["Passport"].ToString(), System.IO.FileMode.Open))
                        {
                            bt = new Bitmap(fs);
                        }
                            
                    }
                    else
                    {
                        using (System.IO.FileStream fs = new System.IO.FileStream(Application.StartupPath + "/default.png", System.IO.FileMode.Open))
                        {
                            bt = new Bitmap(fs);
                        }
                            
                    }

                    grid.Rows.Add(
                            dr["ID"].ToString(),
                            dr["MemberName"].ToString(),
                            dr["ID_Num"].ToString(),
                            dr["PhoneNumber"].ToString(),
                            dr["TotalShares"].ToString(),
                            bt,
                            dr["TotalShares"].ToString(),
                            dr["DateReg"].ToString()
                        );
                }
            }


        }

        private void SearchMembers(string name, string idnum, string phone, string sql = "SELECT * FROM [members] WHERE [MemberName] LIKE @name AND [ID_num] LIKE @id AND [PhoneNumber] LIKE @phone")
        {
            OleDbCommand cmd = new OleDbCommand();
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("name", "%" + name + "%");
            cmd.Parameters.AddWithValue("id", "%" + idnum + "%");
            cmd.Parameters.AddWithValue("phone", "%" + phone + "%");
            DataTable dt = db.ReadFromDB(cmd);

            loadMembers2Grid(dt);

        }

        private void LoadMembers(string sql = "SELECT * FROM [members]")
        {
            OleDbCommand cmd = new OleDbCommand();
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            DataTable dt = db.ReadFromDB(cmd);

            loadMembers2Grid(dt);

        }

        private void frmmembers_Load(object sender, EventArgs e)
        {

        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(grid.SelectedRows.Count > 0)
            {
                DialogResult d = MessageBox.Show("Are you sure you want to delete selected members?", "Wakulima Sacco MIS", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if(d == DialogResult.Yes)
                {
                    foreach (DataGridViewRow row in grid.SelectedRows)
                    {
                        OleDbCommand cmd = new OleDbCommand();
                        cmd.CommandText = "DELETE * FROM [members] WHERE [id] = @del";
                        cmd.Parameters.AddWithValue("del", row.Cells["MemberID"].Value);
                        cmd.CommandType = CommandType.Text;
                        db.CreateRecord(cmd);
                    }

                    MessageBox.Show("Members have been deleted successfully", "Wakulima Sacco MIS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadMembers();
                }
            }
        }

        private void closeFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addNewMemberToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmmembernew frm = new frmmembernew();
            DialogResult d= frm.ShowDialog();
            if(d == DialogResult.OK)
            {
                //refresh grid
                LoadMembers();
            } 
        }

        private void editSelectedMemberToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(grid.SelectedRows.Count > 0)
            {
                string MemberID = grid.SelectedCells[0].Value.ToString();
                frmmembersedit frm = new frmmembersedit(MemberID);
                DialogResult d = frm.ShowDialog();
                if(d == DialogResult.OK)
                {
                    LoadMembers();
                }
            }
        }

        private void searchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmsearch frm = new frmsearch();
            DialogResult d = frm.ShowDialog();
            if(d == DialogResult.OK)
            {
                SearchMembers(frm.MemberName, frm.MemberIDNumber, frm.PhoneNumber);
            }
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            reports_dataset itemsLbl = new reports_dataset(); //dataset whose the crystal report gets data from
            DataTable dataTable = itemsLbl.Members;  //data table containing real data
            rptmembers Report = new rptmembers();
           
            int x = 0;
            foreach (DataGridViewRow row in grid.Rows)
            {
                x++;

                DataRow drow = dataTable.NewRow();

                drow["ID"] = row.Cells[0].Value;
                drow["Name"] = row.Cells[1].Value;
                drow["IDNumber"] = row.Cells[2].Value;
                drow["PhoneNumber"] = row.Cells[3].Value;
                drow["TotalShares"] = row.Cells[4].Value;
                drow["Date"] = row.Cells[6].Value;

                dataTable.Rows.Add(drow);
            }

            Report.Database.Tables["Members"].SetDataSource((DataTable)dataTable);
            frmshowreports frm = new frmshowreports(Report, "Members Report");
            frm.ShowDialog();
        }
    }
}
