﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WakulimaSaccoSystem
{
    public partial class frmmembersedit : Form
    {

        string Member_ID = "";

        public frmmembersedit(string MemberID)
        {
            Member_ID = MemberID;
            InitializeComponent();
            LoadMember();
        }

        private void LoadMember(string sql = "SELECT * FROM [members] WHERE [ID] = @id")
        {
            OleDbCommand cmd = new OleDbCommand();
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("id", Member_ID);
            DataTable dt = db.ReadFromDB(cmd);

            if(dt.Rows.Count == 1)
            {
                txtmembername.Text = dt.Rows[0]["MemberName"].ToString();
                txtidnumber.Text = dt.Rows[0]["ID_Num"].ToString();
                txtshares.Text = dt.Rows[0]["TotalShares"].ToString();
                txtphonenumber.Text = dt.Rows[0]["PhoneNumber"].ToString();
                txtpostaladdress.Text = dt.Rows[0]["PostAddress"].ToString();
            }

            

        }

        private void frmmembersedit_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (txtmembername.Text == "")
            {
                MessageBox.Show("The member name is required", "Wakulima Sacco", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtmembername.Focus();
                return;
            }

            if (txtidnumber.Text == "")
            {
                MessageBox.Show("The member identification number is required", "Wakulima Sacco", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtidnumber.Focus();
                return;
            }

            string sql = "UPDATE [members] SET [MemberName] = @name, [ID_num] =  @id, [PhoneNumber] = @phone, [TotalShares] = @shares, [PostAddress] = @postal";
            sql += " WHERE [ID] = @mid";

            OleDbCommand cmd = new OleDbCommand();
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("name", txtmembername.Text);
            cmd.Parameters.AddWithValue("id", txtidnumber.Text);
            cmd.Parameters.AddWithValue("phone", txtphonenumber.Text);
            cmd.Parameters.AddWithValue("shares", txtshares.Text);
            cmd.Parameters.AddWithValue("postal", txtpostaladdress.Text);
            cmd.Parameters.AddWithValue("mid", Member_ID);

            db.CreateRecord(cmd);
            this.DialogResult = DialogResult.OK;
        }
    }
}
