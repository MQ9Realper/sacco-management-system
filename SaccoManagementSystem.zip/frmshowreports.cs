﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CrystalDecisions.ReportSource;

namespace WakulimaSaccoSystem
{
    public partial class frmshowreports : Form
    {
        public frmshowreports(object rptSource, string ReportTittle)
        {
            InitializeComponent();
            RptViewer.ReportSource = rptSource;
            RptViewer.Refresh();
        }

        private void frmshowreports_Load(object sender, EventArgs e)
        {

        }
    }
}
