﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WakulimaSaccoSystem
{
    public partial class frmsplash : Form
    {
        public frmsplash()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void cmdlogin_Click(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.Password == txtpassword.Text || Properties.Settings.Default.Username == txtusername.Text)
            {
                this.DialogResult = DialogResult.OK;

            } else
            {
                MessageBox.Show("Either the username or the password is incorrect. Please try again.", "Wakulima Sacco", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtpassword.Text = "";
                txtusername.Text = "";
                txtusername.Focus();
            }
        }
    }
}
