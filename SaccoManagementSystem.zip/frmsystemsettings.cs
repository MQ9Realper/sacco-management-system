﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WakulimaSaccoSystem
{
    public partial class frmsystemsettings : Form
    {
        public frmsystemsettings()
        {
            InitializeComponent();
            txtinterest.Text = Properties.Settings.Default.Interest.ToString();
            txtusername.Text = Properties.Settings.Default.Username;

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            frmadminpassword frm = new frmadminpassword();
            DialogResult d = frm.ShowDialog();

            if(d == DialogResult.OK)
            {
                Properties.Settings.Default.Interest = (float) Convert.ToDouble(txtinterest.Text);
                Properties.Settings.Default.Save();
                if(txtusername.Text != "" && txtpassword.Text != "")
                {
                    //change password
                    Properties.Settings.Default.Username = txtusername.Text;
                    Properties.Settings.Default.Password = txtpassword.Text;
                    Properties.Settings.Default.Save();
                }

                if (txtadmpassword.Text != "" && txtadmuser.Text != "")
                {
                    //change password
                    Properties.Settings.Default.AdminPassword = txtadmpassword.Text;
                    Properties.Settings.Default.AdminUsername = txtadmuser.Text;
                    Properties.Settings.Default.Save();
                }
            }

        }

        private void frmsystemsettings_Load(object sender, EventArgs e)
        {

        }

        private void txtinterest_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
    }
}
