﻿namespace WakulimaSaccoSystem
{
}

namespace WakulimaSaccoSystem
{


    public partial class reports_dataset
    {
    }
}
namespace WakulimaSaccoSystem {
    
    
    public partial class reports_dataset {
    }
}
